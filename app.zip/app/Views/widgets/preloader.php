<div class="preloader">
    <div class="loading-center">
        <div class="loading-center-absolute">
            <lottie-player src="<?=base_url()?>/public/animations/lf20_3qe7zc29.json"
                           background="transparent" speed="1"  style="width: 300px; height: 300px;" hover loop autoplay>
            </lottie-player>
        </div>
    </div>
</div>