<link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>/public/favicon.ico">
<!-- mobile menu css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/meanmenu.min.css">
<!-- animate css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/animate.min.css">
<!-- nivo slider css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/nivo-slider.css">
<!-- owl carousel css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/owl.carousel.min.css">
<!-- price slider css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/jquery-ui.min.css">
<!-- fontawesome css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/font-awesome.min.css">
<!-- icon font pack css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/pe-icon-7-stroke.css">
<!-- bootstrap css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/bootstrap.min.css">
<!-- default css  -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/default.css">
<!-- style css -->
<link rel="stylesheet" href="<?=base_url()?>/public/style.css">
<link rel="stylesheet" href="<?=base_url()?>/public/js/vendor/jquery-toast-plugin/dist/jquery.toast.min.css">
<!-- responsive css -->
<link rel="stylesheet" href="<?=base_url()?>/public/css/responsive.css">

<!-- modernizr js -->
<script src="<?=base_url()?>/public/js/vendor/modernizr-3.11.2.min.js"></script>
<script src="<?=base_url()?>/public/js/lottie/lottie-player.js"></script>