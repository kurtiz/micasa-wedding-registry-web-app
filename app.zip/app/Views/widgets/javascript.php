<script src="<?=base_url()?>/public/js/vendor/jquery-3.6.0.min.js"></script>
<script src="<?=base_url()?>/public/js/vendor/jquery-migrate-3.3.2.min.js"></script>
<!-- mobile menu js  -->
<script src="<?=base_url()?>/public/js/jquery.meanmenu.min.js"></script>
<!-- scroll-up js -->
<script src="<?=base_url()?>/public/js/jquery.scrollUp.js"></script>
<!-- owl-carousel js -->
<script src="<?=base_url()?>/public/js/owl.carousel.min.js"></script>
<!-- wow js -->
<script src="<?=base_url()?>/public/js/wow.min.js"></script>
<!-- price slider js -->
<script src="<?=base_url()?>/public/js/jquery-ui.min.js"></script>
<!-- elevateZoom js -->
<script src="<?=base_url()?>/public/js/jquery.elevateZoom-3.0.8.min.js"></script>
<!-- nivo slider js -->
<script src="<?=base_url()?>/public/js/jquery.nivo.slider.js"></script>
<!-- bootstrap -->
<script src="<?=base_url()?>/public/js/bootstrap.bundle.min.js"></script>
<!-- plugins -->
<script src="<?=base_url()?>/public/js/plugins.js"></script>
<script src="<?=base_url()?>/public/js/js-cookie.js"></script>
<script src="<?=base_url()?>/public/js/vendor/jquery-toast-plugin/dist/jquery.toast.min.js"></script>
<!-- main js -->
<script src="<?=base_url()?>/public/js/main.js"></script>