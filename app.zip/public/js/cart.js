/**
 *
 * @param id
 * @param name
 * @param price
 * @param quantity
 * @param image
 */
function addToCart(id, name, price, quantity, image) {
    let cart = $("#shopping-cart"); // gets an instance of cart div element
    let cartTotal = $("#cart-total"); // gets an instance of the cart total
    let cachedQuantity = getWithExpiry(`${id}`); // retrieves specific data from the local storage
    $.ajax({ // makes an ajax get request to get product quantity
        url: `http://localhost/micasa/item/quantity/${id}`,
        success: function (result) {
            // cast the response to a json abject
            let queryResult = JSON.parse(result)
            // saves the
            saveWithExpiry(`${id}`, `${queryResult.quantity}`, "3600000")

            if (parseInt(queryResult.quantity) > 0) {
                if (cart.find("#item-" + id).length) {
                    let quantityElement = $(`#item-quantity-${id}`)
                    let priceHandler = $(`#price-handler-${id}`)
                    let newQuantity = parseInt(quantityElement.text()) + quantity
                    // cartTotal =
                    priceHandler.val(newQuantity * price)
                    quantityElement.text(newQuantity)

                    cartTotal.text(overallSum("sum"))

                    $.toast({
                        text: name + ' has been added to your cart',
                        showHideTransition: 'slide',
                        position: "top-right",
                        bgColor: '#fffbdb',
                        textColor: '#1a1a1a',
                        loaderBg: '#ea3a3c',
                        stack: 2
                    })

                } else {

                    let item = `<div id="item-${id}" class="single-cart-box">\n` +
                        `<div class="cart-img">\n` +
                        `<a href="javascript:void(0)"><img\n` +
                        `src="${base_url}${image}"\n` +
                        `alt="cart-image"></a>\n` +
                        `</div>\n` +
                        `<div class="cart-content">\n` +
                        `<h6><a href="javascript:void(0)">${name}</a></h6>\n` +
                        `<span id="item-quantity-${id}"> ${quantity}</span> ` +
                        ` × <span id="item-price-${id}"> ${Number(price).toLocaleString('en-US')}` +
                        `<input id="price-handler-${id}" class="sum" type="text" style="display: none" readonly value="${price}"/></span>\n` +
                        `</div>\n` +
                        `<i onClick="deleteRow(${id}, 'cart-total', 'sum')" style="color: tomato" class="pe-7s-close"></i>\n` +
                        `</div>`

                    cart.append(item)

                    cartTotal.text(overallSum("sum"))

                    $.toast({
                        text: name + ' has been added to your cart',
                        showHideTransition: 'slide',
                        position: "top-right",
                        bgColor: '#fffbdb',
                        textColor: '#1a1a1a',
                        loaderBg: '#ea3a3c',
                        stack: 2
                    })

                }
            }
        }
    })
}

/**
 * calculates the sum of the content of an array
 * @param {array} array the array of numbers to be summed up
 * @return {number} the summed up figure
 */
function array_sum(array) {
    let result = 0;
    for (let i = 0; i < array.length; i++)
        result += Number(array[i]);
    return result;
}


/**
 * calculates the overall total of all the products on the cart table (including the VAT)
 * @param {string} sumClass the class name of all the total prices of each product on the cart
 * @return {string}
 */
function overallSum(sumClass) {
    // gets the value of the class name
    let overallSum = $(`.${sumClass}`);
    // an array to store all the totals of product prices
    let sum_arr = [];

    // loop to push the totals to the array. the idea is to be
    // able to sum the content of the array
    // to get the overall total
    for (let i = 0; i < overallSum.length; i++)
        sum_arr.push(overallSum.eq(i).val());

    let ans = array_sum(sum_arr);
    return Number(ans).toLocaleString();
}


/**
 * deletes the item the cart
 * @param id
 * @param cart_id
 * @param sumClass
 */
function deleteRow(id, cart_id, sumClass) {
    $(`#item-${id}`).remove()
    $(`#${cart_id}`).text(overallSum(`${sumClass}`))
}

/**
 *
 * @param {string} key id for data
 * @param {string} value data to store in local storage
 * @param {string} ttl time for data to live in milliseconds
 */
function saveWithExpiry(key, value, ttl) {
    const now = new Date()

    // `item` is an object which contains the original value
    // as well as the time when it's supposed to expire
    const item = {
        value: value,
        expiry: now.getTime() + ttl,
    }
    localStorage.setItem(key, JSON.stringify(item))
}

/**
 *
 * @param {string} key id to retrieve data
 * @returns {null|*} returns returns data or null if data has expired
 */
function getWithExpiry(key) {
    const itemStr = localStorage.getItem(key)
    // if the item doesn't exist, return null
    if (!itemStr) {
        return null
    }
    const item = JSON.parse(itemStr)
    const now = new Date()
    // compare the expiry time of the item with the current time
    if (now.getTime() > item.expiry) {
        // If the item is expired, delete the item from storage
        // and return null
        localStorage.removeItem(key)
        return null
    }
    return item.value
}


$("#modal-quantity").on("change", function () {
    let max = Number($(this).prop("max"));
    let currentValue = Number($(this).val());
    let productQuantity = $("#product-quantity")
    if(currentValue > max){
        $(this).val(max)
        productQuantity.val(max)
        $.toast({
            text: 'quantity requested exceeded available',
            showHideTransition: 'slide',
            position: "top-right",
            icon: 'error',
            bgColor: '#ea3a3c',
            textColor: '#fffbdb',
            loaderBg: '#ffffff',
            stack: 2
        })
    } else {
        productQuantity.val(currentValue)
    }
})

$("#add-cart").on("click", function () {
    let id = $(this).prop("data-product-id")
    let largeThumbs = $(".largeThumbs")[0].src;
    let productName = $("#product-name").text();
    let productPrice = Number($("#product-price").text());
    let productQuantity = Number($("#product-quantity").val());
    addToCart(id, productName, productPrice, productQuantity, largeThumbs.replace(base_url, ""))
})